const date = new Date();
let el_footer_text = document.getElementById('foot').childNodes[1];
el_footer_text.innerHTML = date.getFullYear() + " " + el_footer_text.innerHTML;