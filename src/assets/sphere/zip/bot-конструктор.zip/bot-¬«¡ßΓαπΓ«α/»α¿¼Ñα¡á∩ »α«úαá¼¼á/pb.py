import telebot
import datetime
from telebot import types
from settings import TG_TOKEN
from messages import COMPETENCIES, ABOUT, HELP, CMD, QU, SUP
import requests
from bs4 import BeautifulSoup

def send_kurs(message):
    url = 'https://bankdabrabyt.by/export_courses.php'
    response = requests.get(url)

    # Используем BeautifulSoup для парсинга HTML
    soup = BeautifulSoup(response.text, 'html.parser')

    # Находим теги <time> и <value> с атрибутом iso="USD"
    time_tag = soup.find('time')
    usd_value_tag = soup.find('value', {'iso': 'USD'})

    # Извлекаем текст из найденных тегов
    time_text = time_tag.text if time_tag else 'Время не найдено'
    usd_buy_rate = usd_value_tag['buy'] if usd_value_tag else 'Курс покупки USD не найден'
    usd_sale_rate = usd_value_tag['sale'] if usd_value_tag else 'Курс продажи USD не найден'

    # Формируем сообщение с полученными данными
    PB_MES = f"Получено от сервера bankdabrabyt.by\n\nДоступ: root\n\nUSD:\nПокупка: {usd_buy_rate}\nПродажа: {usd_sale_rate}\n--\nВремя сервера: {time_text}\n--\n"

