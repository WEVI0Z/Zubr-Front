# -*- coding: utf8 -*-
import telebot
import datetime
from telebot import types
from settings import TG_TOKEN
from messages import COMPETENCIES, ABOUT, HELP, CMD, QU, SUP, ADMIN, JURY, SPECREG
from bs4 import BeautifulSoup
import requests
import random
# Загружаем список интересных фактов

# Создаем бота
bot = telebot.TeleBot(TG_TOKEN)
def load_user_ids(filename):
    with open(filename, 'r') as file:
        return [line.strip() for line in file]
@bot.message_handler(commands=['start'])
def start(message):
    with open('ids.txt', 'r') as file:
        if str(message.from_user.id) in file.read():
            bot.reply_to(message, "Ваш ID уже был записан ранее.")
        else:
            # Запись ID пользователя в файл
            with open('ids.txt', 'a') as file:
                file.write(str(message.from_user.id) + '\n')
            bot.reply_to(message, "Ваш ID был успешно записан для рассылки новостей.")
        current_time = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=3)))  # Minsk time
        hour = current_time.hour
        if 7 <= hour < 12:
            greeting = "🌞Доброе утро"
        elif 12 <= hour < 18:
            greeting = "🌞Добрый день"
        elif 18 <= hour < 21:
            greeting = "🌚Добрый вечер"
        else:
            greeting = "🌚Доброй ночи"

        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
        item1 = types.KeyboardButton("👉О чемпионате")
        item2 = types.KeyboardButton("🌐Сайт")
        item3 = types.KeyboardButton("📃Компетенции")
        item4 = types.KeyboardButton("📞Контакты")
        help = types.KeyboardButton("/help")
        ps = types.KeyboardButton("🌐Полезные ссылки")
        markup.add(item1, item2, item3, item4, help, ps)
        bot.send_message(message.chat.id, f'😀 | {greeting},\nЭто телеграм бот IT-чемпионата "РобИн"\nНажми: \n👉О чемпионате — для получения подробной информации\n🌍Сайт - для перехода на сайт чемпионата ', reply_markup=markup)
# Получение сообщений от юзера

@bot.message_handler(commands=['sendall'])
def send_all(message):
    # Проверка, что отправитель является администратором
    if message.from_user.id == 1076778230 or 826510056:  # Замените на ID вашего администратора
        # Загрузка текста из сообщения
        text_to_send = message.text.split(' ', 1)[1]

        # Загрузка ID пользователей
        user_ids = load_user_ids('ids.txt')

        # Отправка сообщения каждому пользователю
        for user_id in user_ids:
            try:
                bot.send_message(user_id, text_to_send)
            except Exception as e:
                print(f"Ошибка при отправке сообщения пользователю {user_id}: {e}")
    else:
        bot.reply_to(message, "У вас нет прав для выполнения этой команды.")

@bot.message_handler(commands=["connect"])
def send_kurs(message):
    url = 'https://bankdabrabyt.by/export_courses.php'
    response = requests.get(url)

    # Используем BeautifulSoup для парсинга HTML
    soup = BeautifulSoup(response.text, 'html.parser')

    # Находим теги <time> и <value> с атрибутом iso="USD"
    time_tag = soup.find('time')
    usd_value_tag = soup.find('value', {'iso': 'USD'})

    # Извлекаем текст из найденных тегов
    time_text = time_tag.text if time_tag else 'Время не найдено'
    usd_buy_rate = usd_value_tag['buy'] if usd_value_tag else 'Курс покупки USD не найден'
    usd_sale_rate = usd_value_tag['sale'] if usd_value_tag else 'Курс продажи USD не найден'

    # Формируем сообщение с полученными данными
    PB_MES = f"Получено от сервера bankdabrabyt.by\n\nДоступ: root\n\nUSD:\nПокупка: {usd_buy_rate}\nПродажа: {usd_sale_rate}\n--\nВремя сервера: {time_text}\n--\n"
    bot.send_message(message.chat.id, PB_MES)
@bot.message_handler(commands=["help"])
def help(message):
        markup = types.InlineKeyboardMarkup(row_width=2)
        htype0 = types.InlineKeyboardButton(text="💬Связь с организаторами", callback_data="sup")
        htype1 = types.InlineKeyboardButton(text="</>Показать команды", callback_data="cmd")
        htype2 = types.InlineKeyboardButton(text="Частозадаваемые вопросы", callback_data="qu")
        item4 = types.InlineKeyboardButton("Сайт 'РобИн-2024'", url="https://robin-zubronok.by")
        item5 = types.InlineKeyboardButton("Сайт НДЦ «Зубренок»", url="https://zubronok.by")
        markup.add(htype0, htype1, htype2)
        bot.send_message(message.chat.id, HELP, reply_markup=markup)

@bot.callback_query_handler(func=lambda callback: callback.data)
def check_callback_data(callback):
    global waiting_for_message

    if callback.data == 'cmd':
        bot.edit_message_text(chat_id=callback.message.chat.id, message_id=callback.message.id, text=CMD)
    elif callback.data == 'qu':
        bot.edit_message_text(chat_id=callback.message.chat.id, message_id=callback.message.id, text=QU)
    elif callback.data == 'sup':
        # Начинаем ожидание сообщения пользователя
        waiting_for_message = True
        bot.edit_message_text(chat_id=callback.message.chat.id, message_id=callback.message.id, text=SUP)

@bot.message_handler(commands=['cancel'])
def cancel(message):
    global waiting_for_message
    waiting_for_message = False
    bot.send_message(message.chat.id, "Действие отменено!")

admin_ids = [1076778230, 826510056]

# Создаем словарь для хранения сообщений с уникальными ID
messages_dict = {}

@bot.message_handler(func=lambda message: waiting_for_message)
def send_to_admin(message):
    # Генерируем уникальный ID для сообщения
    message_id = str(random.randint(1, 1000000))
    messages_dict[message_id] = message  # Сохраняем сообщение в словарь

    for admin_id in admin_ids:
        # Отправляем сообщение каждому администратору с уникальным ID
        bot.send_message(admin_id, f"Новое сообщение от пользователя\nID сообщения: {message_id}\nИмя отправителя: {message.from_user.username}\nUser ID: {message.from_user.id}\nТекст:\n{message.text}")
    bot.send_message(message.chat.id, "Сообщение отправлено всем администраторам.")
waiting_for_message = False  # Сбрасываем состояние ожидания

@bot.message_handler(commands=['ans'])
def reply_to_user(message):
    # Разбираем команду на ID сообщения и текст ответа
    command_parts = message.text.split(' ')
    if len(command_parts) < 3:
        bot.send_message(message.chat.id, "Неправильный формат команды. Используйте /ans [id сообщения] [текст ответа]")
        return

    reply_to_id = command_parts[1]
    reply_text = ' '.join(command_parts[2:])

    if reply_to_id in messages_dict:
        original_message = messages_dict[reply_to_id]
        bot.send_message(original_message.chat.id, f"Ответ от администратора: {reply_text}")
    else:
        bot.send_message(message.chat.id, "Сообщение с указанным ID не найдено")

@bot.message_handler(content_types=["text"])
def handle_text(message):
    if message.text.strip() == '👉О чемпионате':
            markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
            item3 = types.KeyboardButton("👈Назад")
            markup.add(item3)
            bot.send_message(message.chat.id, ABOUT, parse_mode='MarkDown', reply_markup=markup)
    elif message.text.strip() == '/about':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        item3 = types.KeyboardButton("👈Назад")
        markup.add(item3)
        bot.send_message(message.chat.id,ABOUT, parse_mode='MarkDown', reply_markup=markup)
    # Если юзер прислал 2, выдаем умную мысль
    elif message.text.strip() == '🌐Сайт':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        item3 = types.KeyboardButton("👈Назад")
        markup.add(item3)
        markup = types.InlineKeyboardMarkup()
        item4 = types.InlineKeyboardButton("Сайт 'РобИн-2024'", url="https://it.robin-zubronok.by")
        item5 = types.InlineKeyboardButton("Сайт НДЦ «Зубренок»", url="https://zubronok.by")
        markup.add(item4, item5)
        bot.send_message(message.chat.id, "🌐Ссылки на сайты ниже 👇", reply_markup=markup)

    elif message.text.strip() == '/site':
        answer = "https://robin-zubronok.by"
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        item3 = types.KeyboardButton("👈Назад")
        markup.add(item3)
        markup = types.InlineKeyboardMarkup()
        item4 = types.InlineKeyboardButton("Сайт 'РобИн-2024'", url="https://it.robin-zubronok.by")
        item5 = types.InlineKeyboardButton("Сайт НДЦ «Зубренок»", url="https://zubronok.by")
        markup.add(item4, item5)
        bot.send_message(message.chat.id, "🌐Ссылки на сайты ниже 👇", reply_markup=markup)

    elif message.text.strip() == '👈Назад':
        start(message)

    elif message.text.strip() == '📞Контакты':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        item3 = types.KeyboardButton("👈Назад")
        markup.add(item3)
        markup = types.InlineKeyboardMarkup()
        item5 = types.InlineKeyboardButton("Telegram канал", url="https://t.me/NCC_Zubronok_by")
        item6 = types.InlineKeyboardButton("Instagram", url="https://intagram.com/@dvorets_zubrenok")
        item7 = types.InlineKeyboardButton("Tik-Tok", url="https://www.tiktok.com/@robolizer_zubrenok")
        markup.add(item5, item6, item7)
        bot.send_message(message.chat.id,"📩Социальные сети и контакты\n\nАдрес оргкомитета:\n222397, Минская область, Мядельский р-н, поселок Зубреневка, НДЦ «Зубренок», Чемпионат «РобИн-2024». Телефоны: 8 (01797) 22 784 (факс), +375298008175 (моб. Viber)\nКонтактное лицо: [Елисей Андреевич Тарасов](http://t.me/@elisey801)\n\n📧Email - info@robin-zubronok.by", reply_markup=markup, parse_mode='MarkDown')

    elif message.text.strip() == '📃Компетенции':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        item3 = types.KeyboardButton("👈Назад")
        markup.add(item3)
        bot.send_message(message.chat.id, COMPETENCIES, reply_markup=markup)
    elif message.text.strip() == '/contacts':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        item3 = types.KeyboardButton("👈Назад")
        markup.add(item3)
        markup = types.InlineKeyboardMarkup()
        item5 = types.InlineKeyboardButton("Telegram канал", url="https://t.me/NCC_Zubronok_by")
        item6 = types.InlineKeyboardButton("Instagram", url="https://intagram.com/@dvorets_zubrenok")
        item7 = types.InlineKeyboardButton("Tik-Tok", url="https://www.tiktok.com/@robolizer_zubrenok")
        markup.add(item5, item6, item7)
        bot.send_message(message.chat.id, "📩Социальные сети и контакты\n\n📧Email - profil@zubronok.by", reply_markup=markup)

    elif message.text.strip() == '/competencies':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        item3 = types.KeyboardButton("👈Назад")
        markup.add(item3)
        bot.send_message(message.chat.id, COMPETENCIES, reply_markup=markup)
    elif message.text.strip() == '🌐Полезные ссылки':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        item3 = types.KeyboardButton("👈Назад")
        markup.add(item3)
        markup = types.InlineKeyboardMarkup()
        item4 = types.InlineKeyboardButton("Moodle", url="https://moodle.robin-zubronok.by")
        item5 = types.InlineKeyboardButton("Электронный репозиторий", url="https://files.robin-zubronok.by")
        markup.add(item4, item5)
        bot.send_message(message.chat.id, "🌐Ссылки на сайты ниже 👇", reply_markup=markup)

    elif message.text.strip() == '/ps':
        answer = "https://robin-zubronok.by"
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        item3 = types.KeyboardButton("👈Назад")
        markup.add(item3)
        markup = types.InlineKeyboardMarkup()
        item4 = types.InlineKeyboardButton("Moodle", url="https://moodle.robin-zubronok.by")
        item5 = types.InlineKeyboardButton("Электронный репозиторий", url="https://files.robin-zubronok.by/login")
        markup.add(item4, item5)
        bot.send_message(message.chat.id, "🌐Полезные ссылки 👇", reply_markup=markup)

    else:

        bot.send_message(message.chat.id, "Команда не найдена\n/help для помощи")




# Запускаем бота
bot.infinity_polling()
