@bot.message_handler(commands=["login"])
def login(message):
    current_time = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=3)))  # Minsk time
    hour = current_time.hour
    if 7 <= hour < 12:
        greeting = "🌞Доброе утро"
    elif 12 <= hour < 18:
        greeting = "🌞Добрый день"
    elif 18 <= hour < 21:
        greeting = "🌚Добрый вечер"
    else:
        greeting = "🌚Доброй ночи"

    markup = types.InlineKeyboardMarkup()
    admin = types.InlineKeyboardButton(text="Администратор", callback_data="admin")
    jury = types.InlineKeyboardButton(text="Судбя", callback_data="jury")
    sreg = types.InlineKeyboardButton(text="Спец.рег", callback_data="specreg")

    markup.add(admin, jury, sreg)
    bot.send_message(message.chat.id,
                     f'😀 | {greeting},\nЭто телеграм бот IT-чемпионата "РобИн"\nВыбрано: вход в панель админитратора \n\nВыберите себя ниже ',
                     reply_markup=markup)

@bot.callback_query_handler(func=lambda callback: callback.data)
def check_callback_login_data(callback):

    if callback.data == 'admin':
        bot.edit_message_text(chat_id=callback.message.chat.id, message_id=callback.message.id, text=ADMIN)
    elif callback.data == 'jury':
        bot.edit_message_text(chat_id=callback.message.chat.id, message_id=callback.message.id, text=JURY)
    elif callback.data == 'specreg':
        bot.edit_message_text(chat_id=callback.message.chat.id, message_id=callback.message.id, text=SPECREG)